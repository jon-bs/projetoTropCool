INSERT INTO funcionario (id, created, nome, login, email, ativo,senha) 
VALUES 
(1001, now(), 'Mírio Costa Ricardo', 'mirio', 'mirio@example.com', true,  'abstrasc'),
(1002, now(), 'Luiz Peres Serrana', 'perino', 'luiz@example.com', false,  'asdhjyg'),
(1003, now(), 'Marcelo Arenhart', 'hartstag', 'marcelo@example.com', true, 'asdhjyf'),
(1004, now(), 'Roberto Carlos', 'rei', 'rei@example.com', true, 'asdghkv');
