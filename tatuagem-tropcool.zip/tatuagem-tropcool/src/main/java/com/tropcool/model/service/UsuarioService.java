package com.tropcool.model.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.tropcool.model.entity.Usuario;
import com.tropcool.model.repository.UsuarioRepository;

@Service
@Transactional
public class UsuarioService {
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	public Usuario cadastrarUsuario(Usuario usuario) {
		return this.usuarioRepository.save(usuario);
	}
	
	public Usuario detalharUsuario(Long id) {
		Usuario usuario = this.usuarioRepository.findById(id).orElse(null);
		Assert.notNull(usuario,"Usuario de id "+ id + "não encontrado.");
		return usuario;
	}
	
	public List<Usuario> listarUsuarios(){
		return this.usuarioRepository.findAll();
	}
	
	public Usuario atualizarUsuario(Usuario usuario) {
		return this.usuarioRepository.save(usuario);
	}
	
	public void removerUsuario(Long id) {
		this.usuarioRepository.deleteById(id);
	}
}
