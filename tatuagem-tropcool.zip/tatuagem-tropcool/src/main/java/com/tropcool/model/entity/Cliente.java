package com.tropcool.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import lombok.Data;

@Data
@Entity
public class Cliente extends AbstractEntity implements Serializable{
    @NotNull
    private Usuario usuario;
    @Column(unique = true, nullable = false, length = 11)
	private String cpf;
    @Column(length = 11)
	private String telefone;
}
