package com.tropcool.model.entity;


public class Endereco {
    private String cidade;
    private String estado;
    private String numero;
    private String rua;
    private String cep;
}
