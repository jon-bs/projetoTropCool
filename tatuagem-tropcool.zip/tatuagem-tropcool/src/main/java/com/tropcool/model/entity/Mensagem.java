package com.tropcool.model.entity;

import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Entity
@Data
public class Mensagem {
	@NotNull
    private Usuario remetente;
	@NotNull
    private Usuario destinatario;
	@NotBlank
    private String explanacao;
    private Boolean lido;
}
