package com.tropcool.model.entity;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
public class Post extends AbstractEntity{
	@NotNull
    private Tatuador tatuador;
    private Boolean bloqueado;
    private byte[] imagem;
}
