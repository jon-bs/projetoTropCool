package com.tropcool.model.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
public class HorarioAgendado {
	@NotNull
    private LocalDateTime horario;
	@NotNull
    private ConfiguracaoAgenda configuracao;
	@NotNull
    private Cliente cliente;
}
