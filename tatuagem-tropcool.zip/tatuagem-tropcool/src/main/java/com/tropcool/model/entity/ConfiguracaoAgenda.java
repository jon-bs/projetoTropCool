package com.tropcool.model.entity;

import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Entity
@Data
public class ConfiguracaoAgenda {
	@NotNull
	private LocalTime horaInicio;
	@NotNull
	private LocalTime horaTermino;
	@NotNull
	@Enumerated( EnumType.ORDINAL )
	private DiaSemanaEnum dia;
	
}
