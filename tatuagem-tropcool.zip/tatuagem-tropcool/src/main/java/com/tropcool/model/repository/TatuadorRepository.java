package com.tropcool.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tropcool.model.entity.Tatuador;

public interface TatuadorRepository extends JpaRepository<Tatuador, Long> {

}
