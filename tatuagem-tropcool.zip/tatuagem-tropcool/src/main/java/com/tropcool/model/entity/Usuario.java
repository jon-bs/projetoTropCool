package com.tropcool.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
public class Usuario extends AbstractEntity implements Serializable{
	//private static final long serialVersionUID 1L;
	@NotBlank
	@Column(unique = true, nullable = false, length = 20)
	private String login;
	@NotBlank
	@Column(unique = false, nullable = false, length = 16)
	private String senha;
	@NotBlank // Não em branco
	private String nome;
	@NotBlank
	private String email;
	private Boolean ativo; 
}
