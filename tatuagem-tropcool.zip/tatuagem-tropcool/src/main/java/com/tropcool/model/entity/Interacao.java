package com.tropcool.model.entity;

import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
public class Interacao extends Mensagem{
	
}
