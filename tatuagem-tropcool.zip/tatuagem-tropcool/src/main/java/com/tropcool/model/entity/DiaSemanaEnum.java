package com.tropcool.model.entity;

public enum DiaSemanaEnum {
	DOMINGO,
    SEGUNDA,
    TERCA,
    QUARTA,
    QUINTA,
    SEXTA,
    SABADO
}
